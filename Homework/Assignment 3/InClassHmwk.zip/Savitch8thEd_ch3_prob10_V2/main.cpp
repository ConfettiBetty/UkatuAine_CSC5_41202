/* 
    File:   main.cpp
    Author: Dr. Mark E. Lehr
    Created on January 4, 2016, 10:18 AM
    Purpose:  Check out IDE, Helloworld
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    
    //Input data
    
    //Calculate or map inputs to outputs
    
    //Output the results
    cout<<"Hello World"<<endl;
    int dum;
    cin>>dum;

    //Exit stage right
    return 0;
}