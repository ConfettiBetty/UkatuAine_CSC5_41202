/* 
  File:   main.cpp
  Author: Aine (Phyllis) Ukatu
 Created on January 5, 2016, 11:40 AM
 Purpose: Mega CS!*/
//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Executive Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    char letC='C';
    char letS='S';
    char exclmtn='!';
    char letO='O'
    
    //Output the results
    ;cout<<"  "<<letC<<letC<<letC<<"       "<<letS<<letS<<letS<<letS<<"     "<<exclmtn<<exclmtn<<endl;
    cout<<" "<<letC<<"   "<<letC<<"     "<<letS<<"    "<<letS<<"    "<<exclmtn<<exclmtn<<endl;
    cout<<letC<<"         "<<letS<<"      "<<letS<<"   "<<exclmtn<<exclmtn<<endl;
    cout<<letC<<"           "<<letS<<"        "<<exclmtn<<exclmtn<<endl;
    cout<<letC<<"            "<<letS<<letS<<letS<<"     "<<exclmtn<<exclmtn<<endl;
    cout<<letC<<"               "<<letS<<"    "<<exclmtn<<exclmtn<<endl;
    cout<<letC<<"                "<<letS<<"   "<<exclmtn<<exclmtn<<endl;
    cout<<" "<<letC<<"   "<<letC<<"          "<<letS<<"    "<<exclmtn<<exclmtn<<endl;
    cout<<"  "<<letC<<letC<<letC<<"       "<<letS<<letS<<letS<<letS<<"     "<<letO<<letO<<endl;
    //Exit
    
    return 0;

                                }