/* 
  File:   main.cpp
  Author: Aine (Phyllis) Ukatu
 Created on January 5, 2016, 11:40 AM
 Purpose: Giant C*/
//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Executive Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    char letter='C';
     
    //Output the results
    cout<<"  "<<letter<<letter<<letter<<endl;
    cout<<" "<<letter<<"   "<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<" "<<letter<<"   "<<letter<<endl;
    cout<<"  "<<letter<<letter<<letter<<endl;
    //Exit
    
    return 0;

                                }