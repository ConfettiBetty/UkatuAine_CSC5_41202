/* 
 * Author: Aine Ukatu
 * Created on January 10, 2016, 11:31 PM
 * Purpose:  Gaddis 7thEd Chapter 2 Problem 15
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Declare variable
char star='*';

//Execution Begins Here
int main(int argc, char** argv) {
        
    //Output the results
    cout<<"   "<<star<<"   "<<endl;
    cout<<"  "<<star<<star<<star<<"  "<<endl;
    cout<<" "<<star<<star<<star<<star<<star<<" "<<endl;
    cout<<star<<star<<star<<star<<star<<star<<star<<endl;
    
    //Exit stage right
    return 0;
}

