/* 
  File:   main.cpp
  Author: Aine (Phyllis) Ukatu
 Created on January 5, 2016, 11:15 AM
 Purpose: No Mistakes*/
//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Executive Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    short d,c,b=25,a=5;
    //Calculate or map using input or outputs
    c=a+b;
    d=a*b;
    
    //Output the results
    cout<<"a = "<<a<<endl;
    cout<<"b = "<<b<<endl;
    cout<<c<< "=" <<a<< "+" <<b<<endl;
    cout<<"This is the end of the program."<<endl;
    //Exit
    
    return 0;

                                }